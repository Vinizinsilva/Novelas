<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu</title>
    <link rel="stylesheet" href="estilo.css">
</head>
<body>
<div class="banner">
    <img src="imagens/banner3.png">
</div>
<div class="texto">
  <h2>ENTRETENIMENTO</h2>
</div>
<div class="novelas">
    <a href="novelas.php"><img src="imagens/Group 4.png"></a>
</div>
    <br><br>
<div class="series">
    <a href="series.php"><img src="imagens/Group 5.png"></a>
</div>
</body>
</html>