<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Novelas</title>
</head>
<body>
<div class="banner">
<img src="imagens/banner1.png">
</div>
<div class="texto">
<h2>Cadastre suas Novelas Favoritas</h2>
</div>
    <hr>
    <br>
    <form method="post" id="cadastro" action="cadastrarnovelas.php">
    <fieldset id="cad">
    <legend>Novelas</legend>
    <p><label for="nome">nome:</label><input type="text" name="nome" id="nome" size="36" maxlenght="100"></p>
    <p><label for="atrizprotagonista">Atriz Protagonista:</label><input type="text" name="atrizprotagonista" id="atrizprotagonista" size="28" maxlenght="100"></p> 
    <p><label for="atorprotagonista">Ator Protagonista:</label><input type="text" name="atorprotagonista" id="atorprotagonista" size="28" maxlenght="100"></p>
    <p><label for="totalepisodios">Total Episódios:</label><input type="number" name="totalepisodios" id="totalepisodios" size="30" maxlenght="100"></p>
    <p>Sinopse</p>
    <p><textarea name="sinopse"id="sinopse" class="textarea"></textarea></p>
    <br> 
    <div class="cadastrar"> 
     <input type="image" src="imagens/Group 2.png"></div>
</div>
</form>
<br>
<br>
<br>
<br>
<br>
<div class="rodape">
</div>
</body>
</html>
    <div class="rodape">
<img src="imagens/rodape1.png">
    <hr>
</form>